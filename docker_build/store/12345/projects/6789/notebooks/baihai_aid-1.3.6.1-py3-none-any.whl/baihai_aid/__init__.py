import subprocess
import re

import requests
import json
import pandas
import numpy
import sys
import pandasql
import plotly.express as px
import os

import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def version():
    import pkg_resources
    return pkg_resources.get_distribution(__name__).version

class BaihaiExeception(Exception):
    pass

#from pycode_optimizer import pycode_optimizer as po


def run_sql(teamId, region, sql, datasource, projectId):
    domain_name = os.getenv('DOMAIN_NAME')
    if not domain_name:
        raise BaihaiExeception("Please set env DOMAIN_NAME")
    url = "http://%s/%s/api/v1/command/database/sql" % (domain_name, region)
    data_dict = {"sql": sql, "aliasDB": datasource, "project": projectId}
    cs = {'teamId': teamId, 'region': region}
    r = requests.post(url=url, data=json.dumps(data_dict), headers={
                      "content-type": "application/json"}, cookies=cs, verify=False)
    if r.status_code == 200:
        response = json.loads(r.text)
        last = response['data'][-1]
        if last['code'] == 200:  # this sql run ok
            if isinstance(last['data'], bool):  # update/insert/delete come here
                return None
            else:
                header = last['data']['schema']
                columns = []
                for k, v in sorted(header.items(), key=lambda item: item[1]):
                    columns.append(k)
                to_transform = last['data']['record']
                ret = pandas.DataFrame(to_transform, columns=columns)
                return ret
        else:
            raise BaihaiExeception(
                "failed execute #%s# at #%s# -> %s " % (sql, datasource, last['message']))
    else:
        raise BaihaiExeception(
            "failed execute #%s# at #%s# " % (sql, datasource))


def real_path(base, stub, aim):
    if aim.startswith("/"):
        return (base + aim).encode('utf8')
    else:
        return (base + os.path.dirname(stub) + "/" + aim).encode('utf8')


def csv_sql(raw_sql, local_base, caller):
    p1 = re.compile(r"from\s+([^\s]+)\b", flags=re.IGNORECASE)
    p2 = re.compile(r"select", flags=re.IGNORECASE)
    csv_files = p1.findall(raw_sql)
    is_select = p2.findall(raw_sql)
    if not (len(csv_files) == 1 and is_select):
        raise BaihaiExeception("Sorry, now we only support SELECT")
    else:
        csv_file = csv_files[0]
        real_file = real_path(local_base, caller, csv_file)
        df_name = '__baihai_df'
        if os.path.isfile(real_file):
            f = open(real_file, mode="r", encoding="utf-8")
            __baihai_df = pandas.read_csv(f, encoding="utf-8")
            new_sql = raw_sql.replace(csv_file, df_name)
            return pandasql.sqldf(new_sql)
        else:
            raise BaihaiExeception("File %s not exist" % csv_file)


def load_or_skip(path):
    try:
        if 'dill' in sys.modules:
            pass
        else:
            import dill
            dill.load_session(path)
    except:
        pass


def after_run(session_path, var_path):
    try:
        import dill
        dill.dump_session(session_path)
        save_vars(var_path)
    except:
        pass


def is_jsonable(x):
    try:
        json.dumps(x)
        return True
    except:
        return False

def type2json(x):

    if type(x) == pandas.core.frame.DataFrame:
        meta = {"columns": list(x.columns)}
        return "dataframe", x.to_json(force_ascii=False), json.dumps(meta)

    elif type(x) == numpy.ndarray or type(x) == pandas.core.arrays:
        y = pandas.DataFrame.from_dict(x)
        meta = {"columns": list(y.columns)}
        return "array", str(x), json.dumps(meta)
    elif type(x) == dict:
        return "dict", str(x), None
    elif 'Tensor' in str(type(x)):
            return "Tensor", str(x), None
    else:
        try:
            type_str = str(type(x))
            y = pandas.DataFrame.from_dict(dict(x), orient="index")
            meta = {"columns": list(y.columns)}
            return type_str, str(x), json.dumps(meta)
        except:
            if is_jsonable(x):
                return type(x).__name__, str(x), "{}"
            else:
                return None, None, "{}"


def save_vars(path):
    var_limit_bytes = 1 * 1024 * 1024
    ret = []
    import __main__ as _main_module
    for f in dir(_main_module):
        if not f.startswith('_') and f != "In" and f != "Out" and (not f.startswith('baihai_aid')):
            aim = eval("_main_module.%s" % f)
            if sys.getsizeof(aim) < var_limit_bytes:
                t, v, m = type2json(aim)
                if t:
                    item = {"name": f, "type": t, "value": v, "meta": m}
                    ret.append(item)
    with open(path, 'w') as fd:
        json.dump(ret, fd)

fn_dict = {
    "point" : px.scatter,
    "line"  : px.line,
    "area"  : px.area
}

def draw_dataframe_bak(df: pandas.DataFrame, x_col, y_col, color_col, pic_type, title):
    if not isinstance(df, pandas.DataFrame):
        raise BaihaiExeception("Sorry, we only support DataFrame")
    else:
        arg_dict = {'x':x_col, 'y':y_col, 'color':color_col, 'title': title}
        n_dict = {k: v for k, v in arg_dict.items() if (v is not None and len(v) > 0)}
        draw_fn = fn_dict.get(pic_type, px.scatter)
        fig = draw_fn(df, **n_dict)
        return fig.to_html(full_html=False, include_plotlyjs="cdn")

def draw_dataframe(df: pandas.DataFrame, arg_dict_str: str):
    if not isinstance(df, pandas.DataFrame):
        raise BaihaiExeception("Sorry, we only support DataFrame")
    else:
        arg_dict = json.loads(arg_dict_str)
        pic_type = arg_dict.get('pic_type')
        del arg_dict['pic_type']
        n_dict = {k: v for k, v in arg_dict.items() if (v is not None and len(v) > 0)}
        draw_fn = fn_dict.get(pic_type, px.scatter)
        fig = draw_fn(df, **n_dict)
        return fig.to_html(full_html=False, include_plotlyjs="cdn")

def execute(cmd):
    popen = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT, universal_newlines=True)
    for stdout_line in iter(popen.stdout.readline, ""):
        yield stdout_line
    popen.stdout.close()
    return_code = popen.wait()
    if return_code:
        raise BaihaiExeception(
            "Failed to execute command: %s, return %s" % (cmd, return_code))


def fake_shell(cmd):
    for line in execute(cmd):
        print(line, end='')

def current_bin():
    return sys.executable

def current_pip():
    return  os.path.join(os.path.dirname(current_bin()), "pip")

def current_env():
    sp = current_bin().split("/")
    if "envs" in sp:
        return sp[sp.index("envs") + 1]
    else:
        return None

def update():
    if current_env() == None:
        print("current env is not a conda env, self updating is not support yet")
        return
    # python_version: str python39 or python38
    import requests
    import time
    import subprocess

    # get aim_version
    r = requests.get(
        r"http://baihai.cn-bj.ufileos.com/baihai-lib/baihai_aid/VERSION.txt"
    )
    aim_version = str(r.content, "utf-8").strip()
    # get current_version
    try:
        cmd = f"{current_bin()} -c 'print(__import__(\"baihai_aid\").version())'"
        result = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
        while True:
            outstr = result.stdout.readline().decode("utf-8").strip()
            if outstr:
                break
        current_version = outstr
        # if current_version== aim_version
        if current_version >= aim_version:
            return f"The baihai_aid version {aim_version} exist."
        else:
            print(f"{current_version} < {aim_version}, will update")
            # TODO: ugly, need extract the following try block into a function
    except ModuleNotFoundError:
        pass
    # if current version != aim_version
    try:

        def run_cmd_with_output(cmd):
            result = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
            i = 0  # time counter
            while True:
                outstr = result.stdout.readline().decode("utf-8").strip()
                if outstr:
                    print(outstr)
                    i = 0
                else:
                    time.sleep(1)
                    i += 1
                if i >= 5:
                    break

        # pip install baihai_aid==aim_version
        aim_file_str = f"baihai_aid-{str(aim_version)}-py3-none-any.whl"
        r = requests.get(
            f"http://baihai.cn-bj.ufileos.com/baihai-lib/baihai_aid/{aim_file_str}"
        )
        with open(aim_file_str, "wb") as f:
            f.write(r.content)

        # install into self path
        cmd = f"{current_pip()} install -U --force {aim_file_str}"
        run_cmd_with_output(cmd)
        
        os.remove(aim_file_str)
        return f"Successfully update baihai_aid to {aim_version}!"
    except TypeError:
        return f"The version {aim_version} doesn't exist.", 400
